# 最终运行指南

## 进入项目目录

在 Windows PowerShell 中进入含有 `scripts` 和 `outputs` 的项目根目录，例如：

```powershell
cd "C:\Users\Administrator\Desktop\multi_arm_course_project-main"
```

路径中如果有空格或括号，必须加英文双引号。

## 一键复现非线性分析

```powershell
python scripts\analyze_basic_mode_decision_summary.py
python scripts\nonlinear_task_structure_optimization.py
python scripts\nonlinear_third_arm_activation_cost.py
python scripts\nonlinear_robust_mode_selection.py
python scripts\nonlinear_switching_boundary_optimization.py
python scripts\nonlinear_integrated_policy_decision.py
python scripts\nonlinear_make_figures.py
python scripts\nonlinear_advanced_extensions.py
```

## 查看最终图表

```powershell
explorer outputs\nonlinear_programming\figures
explorer outputs\nonlinear_programming\advanced_extensions\figures
```

最建议放进报告的图：

```text
fig_heatmap_3arm_ratio_gamma_1.png
fig_critical_lambda_star_gamma_1_K_8.png
fig_pareto_frontier_time_energy.png
fig_chance_constraint_heatmap_alpha_1_0.png
fig_ablation_decision_function_gamma_1_K_8.png
```
