# 多机械臂分类搬运调度优化工程（最终检查版）

## 1. 项目定位

本工程用于运筹学课程大作业，研究二臂与三臂机械臂系统在分类搬运任务中的调度优化与模式选择问题。工程主体包括整数规划/目标规划求解结果、二臂/三臂时间能耗对比，以及基于已有调度结果的非线性决策分析。

当前最终版的非线性部分**不重新建立时间模型，也不重新建立能耗模型**，只使用前面已经得到的二臂/三臂 `Cmax` 和 `total_energy` 结果，进一步分析第三臂是否值得启用。

## 2. 推荐运行方式

进入项目根目录，也就是能看到 `common/`、`parts/`、`scripts/`、`outputs/` 的目录。

安装依赖：

```bash
pip install -r requirements.txt
```

若只复现已生成的非线性分析结果，可以依次运行：

```bash
python scripts/analyze_basic_mode_decision_summary.py
python scripts/nonlinear_task_structure_optimization.py
python scripts/nonlinear_third_arm_activation_cost.py
python scripts/nonlinear_robust_mode_selection.py
python scripts/nonlinear_switching_boundary_optimization.py
python scripts/nonlinear_integrated_policy_decision.py
python scripts/nonlinear_make_figures.py
python scripts/nonlinear_advanced_extensions.py
```

核心结果位于：

```text
outputs/mode_decision/
outputs/nonlinear_programming/
outputs/nonlinear_programming/figures/
outputs/nonlinear_programming/advanced_extensions/
outputs/nonlinear_programming/advanced_extensions/figures/
```

## 3. 主要模型逻辑

二臂/三臂对比指标：

```text
eta_T = (Cmax_2B - Cmax_3B) / Cmax_2B * 100
eta_E = (Energy_3B - Energy_2B) / Energy_2B * 100
S_lambda = eta_T - lambda * eta_E
```

综合鲁棒启用决策函数：

```text
S_final = mean(S_lambda) - gamma * std(S_lambda) - K * Phi(p,r)
```

其中：

- `lambda` 表示时间收益与能耗代价之间的偏好权重；
- `gamma` 表示对随机样本波动的鲁棒惩罚强度；
- `K` 表示第三臂固定启用成本权重；
- `Phi(p,r)` 表示由任务规模和任务结构不均衡度决定的非线性启用成本因子。

决策规则：

```text
S_final > 0  -> recommend_3arm
S_final <= 0 -> recommend_2arm
```

## 4. 高分增强模块

最终版补充了三个增强分析，脚本为：

```text
scripts/nonlinear_advanced_extensions.py
```

该脚本生成：

1. `Pareto` 前沿分析：验证二臂/三臂在时间—能耗双目标下的非支配关系；
2. 机会约束分析：检验第三臂在多随机样本下是否稳定优于二臂；
3. 消融分析：对比只看平均收益、加入风险惩罚、加入启用成本后的决策变化。

关键图表包括：

```text
fig_pareto_frontier_time_energy.png
fig_chance_constraint_heatmap_alpha_1_0.png
fig_ablation_decision_function_gamma_1_K_8.png
table_key_ablation_gamma_1_K_8.csv
```

## 5. 数据说明

`outputs/four_case_framework/basic_2B3B_time_energy.csv` 覆盖 16 种任务结构，每种结构 3 个随机种子。`outputs/mode_decision/mode_decision_summary_basic.csv` 为按任务结构汇总后的二臂/三臂模式选择结果。

所有非线性分析均建立在已有二臂/三臂调度结果之上，未引入新的速度—能耗假设。
