# -*- coding: utf-8 -*-
"""第四部分：优化方法 三机械臂调度：独立运行入口。"""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_DIR))

from common.experiment_runner import main_for_scenario  # noqa: E402


if __name__ == "__main__":
    main_for_scenario(
        scenario_id="04_optimized_three_arm",
        scenario_name="第四部分：优化方法 三机械臂调度",
        arm_count=3,
        algorithm="optimized",
    )
