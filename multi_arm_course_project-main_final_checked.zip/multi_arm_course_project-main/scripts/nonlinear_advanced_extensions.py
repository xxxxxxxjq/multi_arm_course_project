"""Advanced nonlinear decision extensions based on existing 2B/3B results only.

This script does NOT rebuild the time model or the energy model.
It only uses the already computed Cmax and energy values from:
  - outputs/mode_decision/mode_decision_summary_basic.csv
  - outputs/four_case_framework/basic_2B3B_time_energy.csv

It adds three high-value analyses:
  1) Pareto frontier analysis for time-energy tradeoff.
  2) Robust chance-constraint analysis of third-arm activation.
  3) Ablation analysis of the nonlinear decision function.
"""

from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT_ROOT = ROOT / "outputs" / "nonlinear_programming" / "advanced_extensions"
FIG_DIR = OUT_ROOT / "figures"
OUT_ROOT.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

MODE_SUMMARY_PATH = ROOT / "outputs" / "mode_decision" / "mode_decision_summary_basic.csv"
RAW_SEED_PATH = ROOT / "outputs" / "four_case_framework" / "basic_2B3B_time_energy.csv"

LAMBDA_VALUES = [0.5, 1, 2, 3, 4, 5, 6, 8, 10, 15]
GAMMA_VALUES = [0, 1, 2]
K_VALUES = [0, 4, 8, 12, 15, 20, 25]
ALPHA_VALUES = [2 / 3, 1.0]


def make_counts_code(row) -> str:
    return f"{int(row['n1'])}{int(row['n2'])}{int(row['n3'])}{int(row['n4'])}"


def scenario_type_from_counts(n1, n2, n3, n4):
    counts = [int(n1), int(n2), int(n3), int(n4)]
    if len(set(counts)) == 1:
        return "balanced"
    max_count = max(counts)
    max_index = counts.index(max_count) + 1
    if max_count >= sum(counts) / 2:
        return f"type{max_index}_dominant"
    if counts[1] == max_count and counts[3] == max_count:
        return "mixed_balanced"
    if counts[0] == max_count and counts[2] == max_count:
        return "mixed_balanced"
    if counts.count(max_count) >= 2:
        return "dual_arm_dominant"
    return "single_arm_dominant"


def structure_phi(n1, n2, n3, n4):
    total = n1 + n2 + n3 + n4
    p = np.array([n1, n2, n3, n4], dtype=float) / total
    r = total / 8.0
    imbalance = float(np.sum((p - 0.25) ** 2) / 0.75)
    # Same nonlinear structure penalty used in the integrated decision model.
    phi = 1.0 + 0.20 * (r ** 2) + 0.25 * imbalance + 0.15 * (p[3] ** 2)
    return round(float(phi), 4), round(float(imbalance), 4), round(float(r), 4), p


def save_fig(name):
    path = FIG_DIR / name
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"saved: {path}")


def load_data():
    summary = pd.read_csv(MODE_SUMMARY_PATH)
    raw = pd.read_csv(RAW_SEED_PATH)

    for df in [summary, raw]:
        if "counts_code" not in df.columns or df.get("counts_code", pd.Series(dtype=object)).isna().any():
            df["counts_code"] = df.apply(make_counts_code, axis=1)
        else:
            df["counts_code"] = df["counts_code"].astype(str)

    if "scenario_type" not in raw.columns:
        raw["scenario_type"] = raw.apply(
            lambda x: scenario_type_from_counts(x["n1"], x["n2"], x["n3"], x["n4"]), axis=1
        )
    return summary, raw


# -----------------------------------------------------------------------------
# 1) Pareto frontier analysis
# -----------------------------------------------------------------------------

def pareto_analysis(summary: pd.DataFrame):
    rows = []
    for _, row in summary.iterrows():
        code = str(row["counts_code"])
        base = {
            "counts_code": code,
            "scenario_type": row.get("scenario_type", "unknown"),
            "total_tasks": int(row["total_tasks"]),
            "n1": int(row["n1"]),
            "n2": int(row["n2"]),
            "n3": int(row["n3"]),
            "n4": int(row["n4"]),
        }
        rows.append({
            **base,
            "mode": "2B",
            "cmax": float(row["mean_cmax_2B"]),
            "energy": float(row["mean_energy_2B"]),
            "eta_T_percent_vs_2B": 0.0,
            "eta_E_percent_vs_2B": 0.0,
        })
        rows.append({
            **base,
            "mode": "3B",
            "cmax": float(row["mean_cmax_3B"]),
            "energy": float(row["mean_energy_3B"]),
            "eta_T_percent_vs_2B": float(row["mean_eta_T_percent"]),
            "eta_E_percent_vs_2B": float(row["mean_eta_E_percent"]),
        })

    pareto = pd.DataFrame(rows)

    # Minimization in both cmax and energy. A point is dominated if another point is no worse
    # in both objectives and strictly better in at least one objective.
    dominated = []
    for i, a in pareto.iterrows():
        is_dom = False
        for j, b in pareto.iterrows():
            if i == j:
                continue
            no_worse = (b["cmax"] <= a["cmax"]) and (b["energy"] <= a["energy"])
            strictly_better = (b["cmax"] < a["cmax"]) or (b["energy"] < a["energy"])
            if no_worse and strictly_better:
                is_dom = True
                break
        dominated.append(is_dom)

    pareto["is_pareto_efficient"] = [not x for x in dominated]
    pareto["dominance_status"] = np.where(pareto["is_pareto_efficient"], "pareto_efficient", "dominated")
    pareto = pareto.sort_values(["is_pareto_efficient", "energy", "cmax"], ascending=[False, True, True])

    pareto.to_csv(OUT_ROOT / "pareto_solution_table.csv", index=False, encoding="utf-8-sig")

    summary_rows = []
    for mode, sub in pareto.groupby("mode"):
        summary_rows.append({
            "mode": mode,
            "solution_count": len(sub),
            "pareto_count": int(sub["is_pareto_efficient"].sum()),
            "mean_cmax": round(float(sub["cmax"].mean()), 4),
            "mean_energy": round(float(sub["energy"].mean()), 4),
            "min_cmax": round(float(sub["cmax"].min()), 4),
            "min_energy": round(float(sub["energy"].min()), 4),
        })
    pd.DataFrame(summary_rows).to_csv(OUT_ROOT / "pareto_summary.csv", index=False, encoding="utf-8-sig")

    # Figure: time-energy scatter with Pareto points highlighted by marker shape.
    plt.figure(figsize=(8, 5))
    for mode in ["2B", "3B"]:
        sub = pareto[pareto["mode"] == mode]
        plt.scatter(sub["energy"], sub["cmax"], label=f"{mode} all", alpha=0.65)
    pf = pareto[pareto["is_pareto_efficient"]].sort_values("energy")
    plt.plot(pf["energy"], pf["cmax"], marker="o", linewidth=1.5, label="Pareto frontier")
    for _, row in pf.iterrows():
        plt.annotate(f"{row['counts_code']}-{row['mode']}", (row["energy"], row["cmax"]), fontsize=7)
    plt.xlabel("Energy")
    plt.ylabel("Cmax")
    plt.title("Pareto frontier of time-energy tradeoff")
    plt.grid(True, alpha=0.3)
    plt.legend()
    save_fig("fig_pareto_frontier_time_energy.png")


# -----------------------------------------------------------------------------
# 2) Robust chance-constraint analysis
# -----------------------------------------------------------------------------

def chance_constraint_analysis(raw: pd.DataFrame):
    rows = []
    for (code, n1, n2, n3, n4, scenario_type, total_tasks), group in raw.groupby(
        ["counts_code", "n1", "n2", "n3", "n4", "scenario_type", "total_tasks"], dropna=False
    ):
        phi, imbalance, r, p = structure_phi(n1, n2, n3, n4)
        group = group.copy()
        group["eta_T_percent"] = (group["cmax_2B_basic"] - group["cmax_3B_basic"]) / group["cmax_2B_basic"] * 100.0
        group["eta_E_percent"] = (group["energy_3B_basic"] - group["energy_2B_basic"]) / group["energy_2B_basic"] * 100.0

        for lam in LAMBDA_VALUES:
            seed_score = group["eta_T_percent"] - lam * group["eta_E_percent"]
            for K in K_VALUES:
                seed_net = seed_score - K * phi
                positive_count = int((seed_net > 0).sum())
                sample_count = int(seed_net.shape[0])
                prob = positive_count / sample_count if sample_count else np.nan
                mean_net = float(seed_net.mean())
                min_net = float(seed_net.min())
                std_net = float(seed_net.std(ddof=0)) if sample_count > 0 else np.nan

                row_base = {
                    "counts_code": code,
                    "scenario_type": scenario_type,
                    "total_tasks": int(total_tasks),
                    "n1": int(n1),
                    "n2": int(n2),
                    "n3": int(n3),
                    "n4": int(n4),
                    "p1": round(float(p[0]), 4),
                    "p2": round(float(p[1]), 4),
                    "p3": round(float(p[2]), 4),
                    "p4": round(float(p[3]), 4),
                    "r": r,
                    "lambda": lam,
                    "activation_cost_K": K,
                    "activation_cost_factor_phi": phi,
                    "sample_count": sample_count,
                    "positive_seed_count": positive_count,
                    "chance_probability": round(prob, 4),
                    "mean_seed_net_score": round(mean_net, 4),
                    "std_seed_net_score": round(std_net, 4),
                    "worst_seed_net_score": round(min_net, 4),
                }
                for alpha in ALPHA_VALUES:
                    alpha_label = "alpha_" + str(alpha).replace(".", "_")
                    row_base[f"chance_recommend_{alpha_label}"] = (
                        "recommend_3arm" if prob >= alpha else "recommend_2arm"
                    )
                rows.append(row_base)

    chance = pd.DataFrame(rows)
    chance.to_csv(OUT_ROOT / "chance_constraint_result.csv", index=False, encoding="utf-8-sig")

    summary_rows = []
    for alpha in ALPHA_VALUES:
        alpha_label = "alpha_" + str(alpha).replace(".", "_")
        col = f"chance_recommend_{alpha_label}"
        for (lam, K), sub in chance.groupby(["lambda", "activation_cost_K"]):
            count3 = int((sub[col] == "recommend_3arm").sum())
            case_count = int(len(sub))
            summary_rows.append({
                "alpha": round(float(alpha), 4),
                "lambda": lam,
                "activation_cost_K": K,
                "case_count": case_count,
                "recommend_3arm_count": count3,
                "recommend_2arm_count": case_count - count3,
                "recommend_3arm_ratio_percent": round(count3 / case_count * 100, 2),
                "mean_chance_probability": round(float(sub["chance_probability"].mean()), 4),
                "note": "chance constraint uses existing seed-level results only; no time-energy remodeling",
            })
    chance_summary = pd.DataFrame(summary_rows)
    chance_summary.to_csv(OUT_ROOT / "chance_constraint_summary.csv", index=False, encoding="utf-8-sig")

    # Heatmaps for alpha=1.0 and alpha=2/3.
    for alpha in ALPHA_VALUES:
        data = chance_summary[chance_summary["alpha"] == round(float(alpha), 4)].copy()
        pivot = data.pivot_table(index="lambda", columns="activation_cost_K", values="recommend_3arm_ratio_percent")
        pivot = pivot.sort_index()
        plt.figure(figsize=(8, 5))
        plt.imshow(pivot.values, aspect="auto", origin="lower")
        plt.colorbar(label="Chance-feasible 3-arm ratio (%)")
        plt.xticks(range(len(pivot.columns)), [str(int(x)) for x in pivot.columns], rotation=45)
        plt.yticks(range(len(pivot.index)), [str(x) for x in pivot.index])
        plt.xlabel("Activation cost K")
        plt.ylabel("Energy penalty weight lambda")
        plt.title(f"Chance-constrained 3-arm feasibility, alpha={round(float(alpha), 2)}")
        name_alpha = str(round(float(alpha), 2)).replace(".", "_")
        save_fig(f"fig_chance_constraint_heatmap_alpha_{name_alpha}.png")


# -----------------------------------------------------------------------------
# 3) Ablation analysis of nonlinear decision function
# -----------------------------------------------------------------------------

def ablation_analysis(raw: pd.DataFrame):
    rows = []
    for (code, n1, n2, n3, n4, scenario_type, total_tasks), group in raw.groupby(
        ["counts_code", "n1", "n2", "n3", "n4", "scenario_type", "total_tasks"], dropna=False
    ):
        phi, imbalance, r, p = structure_phi(n1, n2, n3, n4)
        group = group.copy()
        group["eta_T_percent"] = (group["cmax_2B_basic"] - group["cmax_3B_basic"]) / group["cmax_2B_basic"] * 100.0
        group["eta_E_percent"] = (group["energy_3B_basic"] - group["energy_2B_basic"]) / group["energy_2B_basic"] * 100.0

        for lam in LAMBDA_VALUES:
            seed_score = group["eta_T_percent"] - lam * group["eta_E_percent"]
            mean_score = float(seed_score.mean())
            std_score = float(seed_score.std(ddof=0))
            for gamma in GAMMA_VALUES:
                for K in K_VALUES:
                    values = {
                        "M1_mean_only": mean_score,
                        "M2_mean_minus_risk": mean_score - gamma * std_score,
                        "M3_full_risk_cost": mean_score - gamma * std_score - K * phi,
                    }
                    for model_name, score in values.items():
                        rows.append({
                            "model_name": model_name,
                            "counts_code": code,
                            "scenario_type": scenario_type,
                            "total_tasks": int(total_tasks),
                            "n1": int(n1),
                            "n2": int(n2),
                            "n3": int(n3),
                            "n4": int(n4),
                            "lambda": lam,
                            "gamma": gamma,
                            "activation_cost_K": K,
                            "mean_score": round(mean_score, 4),
                            "std_score": round(std_score, 4),
                            "activation_cost_factor_phi": phi,
                            "model_score": round(float(score), 4),
                            "recommendation": "recommend_3arm" if score > 0 else "recommend_2arm",
                        })

    ablation = pd.DataFrame(rows)
    ablation.to_csv(OUT_ROOT / "ablation_decision_result.csv", index=False, encoding="utf-8-sig")

    summary_rows = []
    for (model_name, lam, gamma, K), sub in ablation.groupby(["model_name", "lambda", "gamma", "activation_cost_K"]):
        count3 = int((sub["recommendation"] == "recommend_3arm").sum())
        case_count = int(len(sub))
        summary_rows.append({
            "model_name": model_name,
            "lambda": lam,
            "gamma": gamma,
            "activation_cost_K": K,
            "case_count": case_count,
            "recommend_3arm_count": count3,
            "recommend_2arm_count": case_count - count3,
            "recommend_3arm_ratio_percent": round(count3 / case_count * 100, 2),
            "mean_model_score": round(float(sub["model_score"].mean()), 4),
        })
    ablation_summary = pd.DataFrame(summary_rows)
    ablation_summary.to_csv(OUT_ROOT / "ablation_decision_summary.csv", index=False, encoding="utf-8-sig")

    # Figure: model ablation under gamma=1, K=8.
    data = ablation_summary[
        (ablation_summary["gamma"] == 1) &
        (ablation_summary["activation_cost_K"] == 8) &
        (ablation_summary["lambda"].isin([4, 6, 8, 10]))
    ].copy()

    plt.figure(figsize=(9, 5))
    model_order = ["M1_mean_only", "M2_mean_minus_risk", "M3_full_risk_cost"]
    x_vals = [4, 6, 8, 10]
    width = 0.22
    x = np.arange(len(x_vals))
    for idx, model_name in enumerate(model_order):
        sub = data[data["model_name"] == model_name].set_index("lambda").reindex(x_vals)
        plt.bar(x + (idx - 1) * width, sub["recommend_3arm_ratio_percent"], width=width, label=model_name)
    plt.xticks(x, [str(v) for v in x_vals])
    plt.xlabel("Energy penalty weight lambda")
    plt.ylabel("3-arm recommendation ratio (%)")
    plt.title("Ablation of decision function, gamma=1, K=8")
    plt.legend()
    plt.grid(axis="y", alpha=0.3)
    save_fig("fig_ablation_decision_function_gamma_1_K_8.png")

    # Compact tables for report use.
    key_ablation = ablation_summary[
        (ablation_summary["gamma"] == 1) &
        (ablation_summary["activation_cost_K"] == 8) &
        (ablation_summary["lambda"].isin([4, 6, 8, 10]))
    ].copy()
    key_ablation.to_csv(OUT_ROOT / "table_key_ablation_gamma_1_K_8.csv", index=False, encoding="utf-8-sig")


if __name__ == "__main__":
    summary_df, raw_df = load_data()
    pareto_analysis(summary_df)
    chance_constraint_analysis(raw_df)
    ablation_analysis(raw_df)
    print("Advanced nonlinear extensions completed.")
    print(f"Output directory: {OUT_ROOT}")
