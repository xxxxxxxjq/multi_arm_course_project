# -*- coding: utf-8 -*-
"""非线性规划拓展 5：综合鲁棒启用策略与最终决策规则。

本脚本是最终综合决策脚本。

重要说明：
    本脚本不调用速度-能耗优化结果，
    不重新建立时间模型，也不重新建立能耗模型；
    只使用前文已经得到的二臂 / 三臂调度结果，以及鲁棒分析和边界分析结果。

输入：
    1. outputs/mode_decision/mode_decision_summary_basic.csv
    2. outputs/nonlinear_programming/robust_mode_selection/robust_mode_selection_result.csv
    3. outputs/nonlinear_programming/switching_boundary_optimization/switching_boundary_result.csv
       第 3 项只用于补充临界 lambda 信息，不参与重新计算能耗。

输出：
    outputs/nonlinear_programming/integrated_policy_decision/
        integrated_policy_parameters.csv
        integrated_policy_decision_result.csv
        integrated_policy_summary.csv
        integrated_policy_key_scenarios.csv

最终综合得分：
    S_final = mean(S_lambda) - gamma*std(S_lambda) - K*Phi(p,r)

决策规则：
    S_final > 0 推荐三臂；
    S_final <= 0 推荐二臂。

运行：
    python scripts/nonlinear_integrated_policy_decision.py
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parents[1]

DEFAULT_SUMMARY_INPUT = (
    PROJECT_DIR / "outputs" / "mode_decision" / "mode_decision_summary_basic.csv"
)
DEFAULT_ROBUST_INPUT = (
    PROJECT_DIR
    / "outputs"
    / "nonlinear_programming"
    / "robust_mode_selection"
    / "robust_mode_selection_result.csv"
)
DEFAULT_BOUNDARY_INPUT = (
    PROJECT_DIR
    / "outputs"
    / "nonlinear_programming"
    / "switching_boundary_optimization"
    / "switching_boundary_result.csv"
)
DEFAULT_OUTPUT_DIR = (
    PROJECT_DIR
    / "outputs"
    / "nonlinear_programming"
    / "integrated_policy_decision"
)

LAMBDA_VALUES = [0.5, 1, 2, 3, 4, 5, 6, 8, 10, 15]
GAMMA_VALUES = [0, 0.5, 1, 1.5, 2]
ACTIVATION_COST_LEVELS = [0, 2, 4, 6, 8, 10, 12, 15, 20, 25]

N_MAX = 8.0
SIZE_WEIGHT = 0.20
IMBALANCE_WEIGHT = 0.25
TYPE4_WEIGHT = 0.15
IMBALANCE_MAX = 0.75

KEY_POLICY_SCENARIOS = [
    {
        "policy_name": "efficiency_oriented",
        "lambda": 2,
        "gamma": 0.5,
        "activation_cost_K": 4,
        "meaning": "time efficiency is important and third-arm activation cost is low",
    },
    {
        "policy_name": "balanced_operation",
        "lambda": 5,
        "gamma": 1,
        "activation_cost_K": 8,
        "meaning": "balanced time-energy preference with moderate robustness requirement",
    },
    {
        "policy_name": "conservative_energy",
        "lambda": 8,
        "gamma": 1.5,
        "activation_cost_K": 10,
        "meaning": "energy saving and robustness are both emphasized",
    },
    {
        "policy_name": "strict_energy_saving",
        "lambda": 10,
        "gamma": 2,
        "activation_cost_K": 12,
        "meaning": "strong energy saving preference and strict robustness requirement",
    },
]


def lambda_label(lam: float) -> str:
    if abs(lam - int(lam)) < 1e-9:
        return str(int(lam))
    return str(lam).replace(".", "_")


def display_number(value: float) -> str:
    if abs(value - int(value)) < 1e-9:
        return str(int(value))
    return str(value)


def safe_float(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def safe_int(value: Any) -> int:
    if value is None or value == "":
        return 0
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def round2(value: float) -> float:
    return round(float(value), 2)


def round4(value: float) -> float:
    return round(float(value), 4)


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def save_csv(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8-sig")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def get_counts_code(row: dict) -> str:
    value = str(row.get("counts_code", "")).strip()
    if value:
        return value
    return f"{safe_int(row.get('n1', 0))}{safe_int(row.get('n2', 0))}{safe_int(row.get('n3', 0))}{safe_int(row.get('n4', 0))}"


def get_total_tasks(row: dict) -> int:
    if "total_tasks" in row:
        return safe_int(row["total_tasks"])
    return (
        safe_int(row.get("n1", 0))
        + safe_int(row.get("n2", 0))
        + safe_int(row.get("n3", 0))
        + safe_int(row.get("n4", 0))
    )


def get_eta_t(row: dict) -> float:
    if "mean_eta_T_percent" in row:
        return safe_float(row["mean_eta_T_percent"])
    return safe_float(row.get("mean_eta_T", 0))


def get_eta_e(row: dict) -> float:
    if "mean_eta_E_percent" in row:
        return safe_float(row["mean_eta_E_percent"])
    return safe_float(row.get("mean_eta_E", 0))


def get_proportions(row: dict) -> tuple[float, float, float, float, float]:
    n1 = safe_float(row.get("n1", 0))
    n2 = safe_float(row.get("n2", 0))
    n3 = safe_float(row.get("n3", 0))
    n4 = safe_float(row.get("n4", 0))
    total = n1 + n2 + n3 + n4
    if total <= 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0
    return n1 / total, n2 / total, n3 / total, n4 / total, total / N_MAX


def imbalance_index(p1: float, p2: float, p3: float, p4: float) -> float:
    raw = (
        (p1 - 0.25) ** 2
        + (p2 - 0.25) ** 2
        + (p3 - 0.25) ** 2
        + (p4 - 0.25) ** 2
    )
    return raw / IMBALANCE_MAX


def activation_cost_factor(p1: float, p2: float, p3: float, p4: float, r: float) -> float:
    return (
        1.0
        + SIZE_WEIGHT * r * r
        + IMBALANCE_WEIGHT * imbalance_index(p1, p2, p3, p4)
        + TYPE4_WEIGHT * p4 * p4
    )


def recommendation(score: float) -> str:
    if score > 0:
        return "recommend_3arm"
    if score < 0:
        return "recommend_2arm"
    return "recommend_2arm"


def load_structure_rows(summary_path: Path) -> list[dict]:
    if not summary_path.exists():
        raise FileNotFoundError(f"Summary input not found: {summary_path}")
    rows = read_csv(summary_path)
    result = []
    for row in rows:
        result.append(
            {
                "counts_code": get_counts_code(row),
                "scenario_type": row.get("scenario_type", ""),
                "total_tasks": get_total_tasks(row),
                "n1": safe_int(row.get("n1", 0)),
                "n2": safe_int(row.get("n2", 0)),
                "n3": safe_int(row.get("n3", 0)),
                "n4": safe_int(row.get("n4", 0)),
                "eta_T_percent": get_eta_t(row),
                "eta_E_percent": get_eta_e(row),
            }
        )
    return result


def load_robust_score_map(robust_path: Path) -> dict[tuple[str, str], dict]:
    robust_map: dict[tuple[str, str], dict] = {}
    if not robust_path.exists():
        return robust_map
    for row in read_csv(robust_path):
        key = (str(row.get("counts_code", "")).strip(), str(row.get("lambda_label", "")).strip())
        if not key[0] or not key[1]:
            continue
        # mean_score 和 std_score 与 gamma 无关；gamma 在综合函数中单独乘。
        robust_map[key] = {
            "mean_score": safe_float(row.get("mean_score", 0)),
            "std_score": safe_float(row.get("std_score", 0)),
            "sample_count": safe_int(row.get("sample_count", 0)),
            "data_source": "robust_mode_selection_result.csv",
        }
    return robust_map


def load_boundary_map(boundary_path: Path) -> dict[tuple[str, str, str], dict]:
    boundary_map: dict[tuple[str, str, str], dict] = {}
    if not boundary_path.exists():
        return boundary_map
    for row in read_csv(boundary_path):
        key = (
            str(row.get("counts_code", "")).strip(),
            str(row.get("gamma", "")).strip(),
            str(row.get("activation_cost_K", "")).strip(),
        )
        if not key[0]:
            continue
        boundary_map[key] = {
            "critical_lambda_star": row.get("critical_lambda_star", ""),
            "boundary_status": row.get("boundary_status", ""),
        }
    return boundary_map


def build_decision_rows(
    structure_rows: list[dict],
    robust_map: dict[tuple[str, str], dict],
    boundary_map: dict[tuple[str, str, str], dict],
) -> list[dict]:
    result_rows = []
    for row in structure_rows:
        p1, p2, p3, p4, r = get_proportions(row)
        phi = activation_cost_factor(p1, p2, p3, p4, r)
        eta_t = safe_float(row["eta_T_percent"])
        eta_e = safe_float(row["eta_E_percent"])
        counts_code = row["counts_code"]

        for lam in LAMBDA_VALUES:
            label = lambda_label(lam)
            lam_text = display_number(lam)
            robust_info = robust_map.get((counts_code, label))
            if robust_info:
                mean_score = safe_float(robust_info["mean_score"])
                std_score = safe_float(robust_info["std_score"])
                sample_count = safe_int(robust_info["sample_count"])
                robust_source = robust_info["data_source"]
            else:
                mean_score = eta_t - lam * eta_e
                std_score = 0.0
                sample_count = 1
                robust_source = "mode_decision_summary_basic.csv"

            for gamma in GAMMA_VALUES:
                gamma_text = display_number(gamma)
                risk_penalty = gamma * std_score
                for k in ACTIVATION_COST_LEVELS:
                    k_text = str(k)
                    activation_penalty = k * phi
                    final_score = mean_score - risk_penalty - activation_penalty
                    final_rec = recommendation(final_score)
                    selected_mode = "3arm" if final_rec == "recommend_3arm" else "2arm"
                    boundary_info = boundary_map.get((counts_code, gamma_text, k_text), {})

                    result_rows.append(
                        {
                            "counts_code": counts_code,
                            "scenario_type": row["scenario_type"],
                            "total_tasks": row["total_tasks"],
                            "n1": row["n1"],
                            "n2": row["n2"],
                            "n3": row["n3"],
                            "n4": row["n4"],
                            "p1": round4(p1),
                            "p2": round4(p2),
                            "p3": round4(p3),
                            "p4": round4(p4),
                            "r": round4(r),
                            "lambda": lam_text,
                            "lambda_label": label,
                            "gamma": gamma_text,
                            "activation_cost_K": k,
                            "eta_T_percent": round2(eta_t),
                            "eta_E_percent": round2(eta_e),
                            "mean_score": round2(mean_score),
                            "std_score": round2(std_score),
                            "risk_penalty": round2(risk_penalty),
                            "activation_cost_factor_phi": round4(phi),
                            "activation_penalty": round2(activation_penalty),
                            "final_integrated_score": round2(final_score),
                            "final_recommendation": final_rec,
                            "selected_mode": selected_mode,
                            "critical_lambda_star_under_gamma_K": boundary_info.get("critical_lambda_star", ""),
                            "boundary_status_under_gamma_K": boundary_info.get("boundary_status", ""),
                            "sample_count": sample_count,
                            "robust_data_source": robust_source,
                            "model_note": "S_final=mean(S_lambda)-gamma*std(S_lambda)-K*Phi(p,r)",
                        }
                    )
    return result_rows


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def build_summary_rows(result_rows: list[dict]) -> list[dict]:
    groups: dict[tuple, list[dict]] = {}
    for row in result_rows:
        key = (row["lambda"], row["lambda_label"], row["gamma"], row["activation_cost_K"])
        groups.setdefault(key, []).append(row)

    summary_rows = []
    for key, rows in sorted(groups.items(), key=lambda x: (safe_float(x[0][0]), safe_float(x[0][2]), safe_float(x[0][3]))):
        lam, label, gamma, k = key
        case_count = len(rows)
        rec_3arm = sum(1 for r in rows if r["final_recommendation"] == "recommend_3arm")
        rec_2arm = sum(1 for r in rows if r["final_recommendation"] == "recommend_2arm")
        final_scores = [safe_float(r["final_integrated_score"]) for r in rows]
        summary_rows.append(
            {
                "lambda": lam,
                "lambda_label": label,
                "gamma": gamma,
                "activation_cost_K": k,
                "case_count": case_count,
                "recommend_3arm_count": rec_3arm,
                "recommend_2arm_count": rec_2arm,
                "recommend_3arm_ratio_percent": round2(rec_3arm / case_count * 100),
                "mean_final_integrated_score": round2(mean(final_scores)),
                "min_final_integrated_score": round2(min(final_scores)),
                "max_final_integrated_score": round2(max(final_scores)),
                "note": "final decision combines mean benefit, robustness penalty and activation cost; no speed-energy remodel is used",
            }
        )
    return summary_rows


def build_key_policy_rows(result_rows: list[dict]) -> list[dict]:
    key_rows = []
    for policy in KEY_POLICY_SCENARIOS:
        target_lam = safe_float(policy["lambda"])
        target_gamma = safe_float(policy["gamma"])
        target_k = safe_float(policy["activation_cost_K"])
        selected_rows = [
            row
            for row in result_rows
            if abs(safe_float(row["lambda"]) - target_lam) < 1e-9
            and abs(safe_float(row["gamma"]) - target_gamma) < 1e-9
            and abs(safe_float(row["activation_cost_K"]) - target_k) < 1e-9
        ]
        selected_rows = sorted(
            selected_rows,
            key=lambda r: safe_float(r["final_integrated_score"]),
            reverse=True,
        )
        for rank, row in enumerate(selected_rows, start=1):
            out = {
                "policy_name": policy["policy_name"],
                "policy_meaning": policy["meaning"],
                "lambda": display_number(target_lam),
                "gamma": display_number(target_gamma),
                "activation_cost_K": int(target_k),
                "rank_by_final_score": rank,
            }
            out.update(row)
            key_rows.append(out)
    return key_rows


def build_parameter_rows() -> list[dict]:
    return [
        {
            "parameter": "lambda_values",
            "value": ",".join(display_number(lam) for lam in LAMBDA_VALUES),
            "meaning": "energy penalty weights",
        },
        {
            "parameter": "gamma_values",
            "value": ",".join(display_number(g) for g in GAMMA_VALUES),
            "meaning": "risk-aversion coefficients",
        },
        {
            "parameter": "activation_cost_K",
            "value": ",".join(str(k) for k in ACTIVATION_COST_LEVELS),
            "meaning": "fixed activation cost levels of enabling the third arm",
        },
        {
            "parameter": "nonlinear_structure_penalty",
            "value": "Phi(p,r)=1+0.20*r^2+0.25*I(p)+0.15*p4^2",
            "meaning": "task structure and scale related nonlinear coordination penalty",
        },
        {
            "parameter": "final_score",
            "value": "S_final=mean(S_lambda)-gamma*std(S_lambda)-K*Phi(p,r)",
            "meaning": "integrated score using existing scheduling results only",
        },
        {
            "parameter": "decision_rule",
            "value": "recommend_3arm if S_final>0 else recommend_2arm",
            "meaning": "final integrated two-arm / three-arm decision rule",
        },
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description="Integrated robust policy decision without speed-energy remodeling.")
    parser.add_argument("--summary-input", default=str(DEFAULT_SUMMARY_INPUT))
    parser.add_argument("--robust-input", default=str(DEFAULT_ROBUST_INPUT))
    parser.add_argument("--boundary-input", default=str(DEFAULT_BOUNDARY_INPUT))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    args = parser.parse_args()

    summary_path = Path(args.summary_input)
    robust_path = Path(args.robust_input)
    boundary_path = Path(args.boundary_input)
    output_dir = Path(args.output_dir)

    structure_rows = load_structure_rows(summary_path)
    robust_map = load_robust_score_map(robust_path)
    boundary_map = load_boundary_map(boundary_path)

    parameter_rows = build_parameter_rows()
    result_rows = build_decision_rows(structure_rows, robust_map, boundary_map)
    summary_rows = build_summary_rows(result_rows)
    key_policy_rows = build_key_policy_rows(result_rows)

    save_csv(parameter_rows, output_dir / "integrated_policy_parameters.csv")
    save_csv(result_rows, output_dir / "integrated_policy_decision_result.csv")
    save_csv(summary_rows, output_dir / "integrated_policy_summary.csv")
    save_csv(key_policy_rows, output_dir / "integrated_policy_key_scenarios.csv")

    print("Integrated robust policy decision finished.")
    print(f"Summary input: {summary_path}")
    print(f"Robust input: {robust_path}")
    print(f"Boundary input: {boundary_path}")
    print(f"Output directory: {output_dir}")
    print(f"Structure rows: {len(structure_rows)}")
    print(f"Robust score entries: {len(robust_map)}")
    print(f"Boundary entries: {len(boundary_map)}")
    print(f"Decision rows: {len(result_rows)}")
    print("Generated:")
    print("  integrated_policy_parameters.csv")
    print("  integrated_policy_decision_result.csv")
    print("  integrated_policy_summary.csv")
    print("  integrated_policy_key_scenarios.csv")
    print("Model:")
    print("  S_final = mean(S_lambda) - gamma*std(S_lambda) - K*Phi(p,r)")
    print("  no new time or energy model is introduced")


if __name__ == "__main__":
    main()
