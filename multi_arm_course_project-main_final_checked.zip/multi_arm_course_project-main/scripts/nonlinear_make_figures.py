from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]

summary_path = ROOT / "outputs" / "nonlinear_programming" / "integrated_policy_decision" / "integrated_policy_summary.csv"
decision_path = ROOT / "outputs" / "nonlinear_programming" / "integrated_policy_decision" / "integrated_policy_decision_result.csv"
boundary_path = ROOT / "outputs" / "nonlinear_programming" / "switching_boundary_optimization" / "switching_boundary_result.csv"

out_dir = ROOT / "outputs" / "nonlinear_programming" / "figures"
out_dir.mkdir(parents=True, exist_ok=True)

summary = pd.read_csv(summary_path)
decision = pd.read_csv(decision_path, dtype={"counts_code": str})
boundary = pd.read_csv(boundary_path, dtype={"counts_code": str})

for df in [summary, decision, boundary]:
    for col in df.columns:
        if col in [
            "lambda", "gamma", "activation_cost_K",
            "recommend_3arm_ratio_percent", "mean_final_integrated_score",
            "final_integrated_score", "critical_lambda_star",
            "score_at_lambda_0_5", "score_at_lambda_15"
        ]:
            df[col] = pd.to_numeric(df[col], errors="coerce")


def save_current(name):
    path = out_dir / name
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"saved: {path}")


# Figure 1-3: heatmaps of 3-arm recommendation ratio under different gamma values
for gamma_value in [0, 1, 2]:
    data = summary[summary["gamma"] == gamma_value].copy()
    pivot = data.pivot_table(
        index="lambda",
        columns="activation_cost_K",
        values="recommend_3arm_ratio_percent",
        aggfunc="mean"
    ).sort_index()

    plt.figure(figsize=(8, 5))
    plt.imshow(pivot.values, aspect="auto", origin="lower")
    plt.colorbar(label="3-arm recommendation ratio (%)")
    plt.xticks(range(len(pivot.columns)), [str(int(x)) for x in pivot.columns], rotation=45)
    plt.yticks(range(len(pivot.index)), [str(x) for x in pivot.index])
    plt.xlabel("Activation cost K")
    plt.ylabel("Energy penalty weight lambda")
    plt.title(f"3-arm recommendation ratio heatmap, gamma={gamma_value}")
    save_current(f"fig_heatmap_3arm_ratio_gamma_{gamma_value}.png")


# Figure 4: recommendation ratio changes with K under gamma=1
data = summary[(summary["gamma"] == 1) & (summary["lambda"].isin([4, 6, 8, 10]))].copy()

plt.figure(figsize=(8, 5))
for lam in [4, 6, 8, 10]:
    sub = data[data["lambda"] == lam].sort_values("activation_cost_K")
    if not sub.empty:
        plt.plot(
            sub["activation_cost_K"],
            sub["recommend_3arm_ratio_percent"],
            marker="o",
            label=f"lambda={lam}"
        )

plt.xlabel("Activation cost K")
plt.ylabel("3-arm recommendation ratio (%)")
plt.title("Mode switching trend under gamma=1")
plt.legend()
plt.grid(True, alpha=0.3)
save_current("fig_mode_switching_ratio_vs_K_gamma_1.png")


# Figure 5: critical lambda star ranking under gamma=1 and K=8
data = boundary[
    (boundary["gamma"] == 1) &
    (boundary["activation_cost_K"] == 8) &
    (boundary["boundary_status"] == "switching_boundary_found")
].copy()

data = data.sort_values("critical_lambda_star", ascending=False)

plt.figure(figsize=(9, 5))
plt.bar(data["counts_code"], data["critical_lambda_star"])
plt.xlabel("Task structure counts_code")
plt.ylabel("Critical lambda star")
plt.title("Critical energy penalty threshold under gamma=1, K=8")
plt.xticks(rotation=45)
plt.grid(axis="y", alpha=0.3)
save_current("fig_critical_lambda_star_gamma_1_K_8.png")


# Figure 6: final integrated score versus K for representative structures
representative_codes = ["1212", "1221", "1111", "1122"]
data = decision[
    (decision["lambda"] == 4) &
    (decision["gamma"] == 1) &
    (decision["counts_code"].isin(representative_codes))
].copy()

plt.figure(figsize=(8, 5))
for code in representative_codes:
    sub = data[data["counts_code"] == code].sort_values("activation_cost_K")
    if not sub.empty:
        plt.plot(
            sub["activation_cost_K"],
            sub["final_integrated_score"],
            marker="o",
            label=code
        )

plt.axhline(0, linestyle="--", linewidth=1)
plt.xlabel("Activation cost K")
plt.ylabel("Final integrated score")
plt.title("Final integrated score versus activation cost, lambda=4, gamma=1")
plt.legend()
plt.grid(True, alpha=0.3)
save_current("fig_final_score_vs_K_lambda_4_gamma_1.png")


# Figure 7: final integrated score versus lambda for representative structures
data = decision[
    (decision["gamma"] == 1) &
    (decision["activation_cost_K"] == 8) &
    (decision["counts_code"].isin(representative_codes))
].copy()

plt.figure(figsize=(8, 5))
for code in representative_codes:
    sub = data[data["counts_code"] == code].sort_values("lambda")
    if not sub.empty:
        plt.plot(
            sub["lambda"],
            sub["final_integrated_score"],
            marker="o",
            label=code
        )

plt.axhline(0, linestyle="--", linewidth=1)
plt.xlabel("Energy penalty weight lambda")
plt.ylabel("Final integrated score")
plt.title("Final integrated score versus lambda, gamma=1, K=8")
plt.legend()
plt.grid(True, alpha=0.3)
save_current("fig_final_score_vs_lambda_gamma_1_K_8.png")


# Export two compact tables for report use
key_summary = summary[
    (summary["lambda"].isin([4, 6, 8, 10, 15])) &
    (summary["gamma"].isin([0, 1, 2])) &
    (summary["activation_cost_K"].isin([0, 8, 15, 25]))
].copy()

key_summary.to_csv(out_dir / "table_key_integrated_policy_summary.csv", index=False, encoding="utf-8-sig")

key_boundary = boundary[
    (boundary["gamma"] == 1) &
    (boundary["activation_cost_K"] == 8)
].sort_values("critical_lambda_star", ascending=False)

key_boundary.to_csv(out_dir / "table_key_switching_boundary_gamma_1_K_8.csv", index=False, encoding="utf-8-sig")

print("All nonlinear visualization figures and key tables have been generated.")
