# -*- coding: utf-8 -*-
"""非线性规划拓展 2：第三臂启用切换边界优化。

本脚本用于替代原来的速度-能耗优化主线。

重要说明：
    本模型不重新建立时间模型，也不重新建立能耗模型；
    只使用前文已经得到的二臂 / 三臂调度结果，以及鲁棒分析中得到的
    mean(S_lambda)、std(S_lambda)。

输入：
    1. outputs/mode_decision/mode_decision_summary_basic.csv
       用于读取任务结构、eta_T、eta_E 等已有结果。
    2. outputs/nonlinear_programming/robust_mode_selection/robust_mode_selection_result.csv
       用于读取每个 lambda 下的 mean_score 和 std_score。

输出：
    outputs/nonlinear_programming/switching_boundary_optimization/
        switching_boundary_parameters.csv
        switching_boundary_result.csv
        switching_boundary_summary.csv
        switching_boundary_key_cases.csv

核心思想：
    在已有综合收益 S_lambda 的基础上，引入固定启用成本和风险惩罚：

        F(lambda, gamma, K)
        = mean(S_lambda) - gamma * std(S_lambda) - K * Phi(p,r)

    其中 Phi(p,r) 是任务结构相关的非线性协调惩罚因子。

    若 F > 0，则第三臂值得启用；
    若 F < 0，则应采用二臂。

    本脚本进一步求解临界能耗权重 lambda*：
        F(lambda*, gamma, K) = 0

    lambda* 越大，说明该任务结构在更强能耗偏好下仍能支撑三臂；
    lambda* 越小，说明三臂启用边界更窄。

运行：
    python scripts/nonlinear_switching_boundary_optimization.py
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parents[1]

DEFAULT_SUMMARY_INPUT = (
    PROJECT_DIR / "outputs" / "mode_decision" / "mode_decision_summary_basic.csv"
)
DEFAULT_ROBUST_INPUT = (
    PROJECT_DIR
    / "outputs"
    / "nonlinear_programming"
    / "robust_mode_selection"
    / "robust_mode_selection_result.csv"
)
DEFAULT_OUTPUT_DIR = (
    PROJECT_DIR
    / "outputs"
    / "nonlinear_programming"
    / "switching_boundary_optimization"
)

LAMBDA_VALUES = [0.5, 1, 2, 3, 4, 5, 6, 8, 10, 15]
GAMMA_VALUES = [0, 0.5, 1, 1.5, 2]
ACTIVATION_COST_LEVELS = [0, 2, 4, 6, 8, 10, 12, 15, 20, 25]

N_MAX = 8.0
SIZE_WEIGHT = 0.20
IMBALANCE_WEIGHT = 0.25
TYPE4_WEIGHT = 0.15
IMBALANCE_MAX = 0.75
EPS = 1e-9


def lambda_label(lam: float) -> str:
    if abs(lam - int(lam)) < 1e-9:
        return str(int(lam))
    return str(lam).replace(".", "_")


def display_number(value: float) -> str:
    if abs(value - int(value)) < 1e-9:
        return str(int(value))
    return str(value)


def safe_float(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def safe_int(value: Any) -> int:
    if value is None or value == "":
        return 0
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def round2(value: float) -> float:
    return round(float(value), 2)


def round4(value: float) -> float:
    return round(float(value), 4)


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def save_csv(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8-sig")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def get_counts_code(row: dict) -> str:
    value = str(row.get("counts_code", "")).strip()
    if value:
        return value
    return f"{safe_int(row.get('n1', 0))}{safe_int(row.get('n2', 0))}{safe_int(row.get('n3', 0))}{safe_int(row.get('n4', 0))}"


def get_total_tasks(row: dict) -> int:
    if "total_tasks" in row:
        return safe_int(row["total_tasks"])
    return (
        safe_int(row.get("n1", 0))
        + safe_int(row.get("n2", 0))
        + safe_int(row.get("n3", 0))
        + safe_int(row.get("n4", 0))
    )


def get_proportions(row: dict) -> tuple[float, float, float, float, float]:
    n1 = safe_float(row.get("n1", 0))
    n2 = safe_float(row.get("n2", 0))
    n3 = safe_float(row.get("n3", 0))
    n4 = safe_float(row.get("n4", 0))
    total = n1 + n2 + n3 + n4
    if total <= 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0
    return n1 / total, n2 / total, n3 / total, n4 / total, total / N_MAX


def imbalance_index(p1: float, p2: float, p3: float, p4: float) -> float:
    raw = (
        (p1 - 0.25) ** 2
        + (p2 - 0.25) ** 2
        + (p3 - 0.25) ** 2
        + (p4 - 0.25) ** 2
    )
    return raw / IMBALANCE_MAX


def activation_cost_factor(p1: float, p2: float, p3: float, p4: float, r: float) -> float:
    """任务结构相关的非线性协调惩罚因子。"""
    imb = imbalance_index(p1, p2, p3, p4)
    return 1.0 + SIZE_WEIGHT * r * r + IMBALANCE_WEIGHT * imb + TYPE4_WEIGHT * p4 * p4


def recommendation(score: float) -> str:
    if score > 0:
        return "recommend_3arm"
    if score < 0:
        return "recommend_2arm"
    return "recommend_2arm"


def load_structure_rows(summary_path: Path) -> list[dict]:
    if not summary_path.exists():
        raise FileNotFoundError(f"Summary input not found: {summary_path}")
    rows = read_csv(summary_path)
    result = []
    for row in rows:
        n1 = safe_int(row.get("n1", 0))
        n2 = safe_int(row.get("n2", 0))
        n3 = safe_int(row.get("n3", 0))
        n4 = safe_int(row.get("n4", 0))
        result.append(
            {
                "counts_code": get_counts_code(row),
                "scenario_type": row.get("scenario_type", ""),
                "total_tasks": get_total_tasks(row),
                "n1": n1,
                "n2": n2,
                "n3": n3,
                "n4": n4,
                "mean_eta_T_percent": safe_float(row.get("mean_eta_T_percent", 0)),
                "mean_eta_E_percent": safe_float(row.get("mean_eta_E_percent", 0)),
            }
        )
    return result


def load_robust_map(robust_path: Path) -> dict[tuple[str, str], dict]:
    robust_map: dict[tuple[str, str], dict] = {}
    if not robust_path.exists():
        return robust_map
    for row in read_csv(robust_path):
        key = (str(row.get("counts_code", "")).strip(), str(row.get("lambda_label", "")).strip())
        if not key[0] or not key[1]:
            continue
        robust_map[key] = {
            "mean_score": safe_float(row.get("mean_score", 0)),
            "std_score": safe_float(row.get("std_score", 0)),
            "sample_count": safe_int(row.get("sample_count", 0)),
        }
    return robust_map


def get_score_curve(row: dict, robust_map: dict[tuple[str, str], dict], gamma: float, k: float) -> list[tuple[float, float, float, float]]:
    """返回 [(lambda, final_score, mean_score, std_score), ...]。"""
    p1, p2, p3, p4, r = get_proportions(row)
    phi = activation_cost_factor(p1, p2, p3, p4, r)
    eta_t = safe_float(row.get("mean_eta_T_percent", 0))
    eta_e = safe_float(row.get("mean_eta_E_percent", 0))
    curve = []
    for lam in LAMBDA_VALUES:
        label = lambda_label(lam)
        info = robust_map.get((row["counts_code"], label))
        if info:
            mean_score = safe_float(info["mean_score"])
            std_score = safe_float(info["std_score"])
        else:
            mean_score = eta_t - lam * eta_e
            std_score = 0.0
        final_score = mean_score - gamma * std_score - k * phi
        curve.append((lam, final_score, mean_score, std_score))
    return curve


def interpolate_root(x1: float, y1: float, x2: float, y2: float) -> float:
    if abs(y2 - y1) <= EPS:
        return x1
    return x1 + (0.0 - y1) * (x2 - x1) / (y2 - y1)


def find_critical_lambda(curve: list[tuple[float, float, float, float]]) -> tuple[str, str]:
    """求 F(lambda)=0 的临界点。返回 (lambda_star, status)。"""
    if not curve:
        return "", "no_data"

    first_lam, first_score, _, _ = curve[0]
    last_lam, last_score, _, _ = curve[-1]

    if first_score <= 0:
        return "0.00", "no_3arm_region_in_tested_lambda_range"

    if last_score > 0:
        return f">{display_number(last_lam)}", "3arm_valid_beyond_tested_lambda_range"

    for i in range(1, len(curve)):
        prev_lam, prev_score, _, _ = curve[i - 1]
        curr_lam, curr_score, _, _ = curve[i]
        if prev_score > 0 and curr_score <= 0:
            root = interpolate_root(prev_lam, prev_score, curr_lam, curr_score)
            return f"{root:.2f}", "switching_boundary_found"

    return "", "irregular_curve"


def build_boundary_rows(structure_rows: list[dict], robust_map: dict[tuple[str, str], dict]) -> list[dict]:
    rows = []
    for row in structure_rows:
        p1, p2, p3, p4, r = get_proportions(row)
        phi = activation_cost_factor(p1, p2, p3, p4, r)

        for gamma in GAMMA_VALUES:
            for k in ACTIVATION_COST_LEVELS:
                curve = get_score_curve(row, robust_map, gamma, k)
                critical_lambda, status = find_critical_lambda(curve)

                score_at_low = curve[0][1] if curve else 0.0
                score_at_high = curve[-1][1] if curve else 0.0
                positive_count = sum(1 for _, score, _, _ in curve if score > 0)

                rows.append(
                    {
                        "counts_code": row["counts_code"],
                        "scenario_type": row.get("scenario_type", ""),
                        "total_tasks": row["total_tasks"],
                        "n1": row["n1"],
                        "n2": row["n2"],
                        "n3": row["n3"],
                        "n4": row["n4"],
                        "p1": round4(p1),
                        "p2": round4(p2),
                        "p3": round4(p3),
                        "p4": round4(p4),
                        "r": round4(r),
                        "gamma": display_number(gamma),
                        "activation_cost_K": k,
                        "activation_cost_factor_phi": round4(phi),
                        "critical_lambda_star": critical_lambda,
                        "boundary_status": status,
                        "positive_lambda_grid_count": positive_count,
                        "tested_lambda_grid_count": len(curve),
                        "score_at_lambda_0_5": round2(score_at_low),
                        "score_at_lambda_15": round2(score_at_high),
                        "boundary_note": "F(lambda,gamma,K)=mean(S_lambda)-gamma*std(S_lambda)-K*Phi(p,r)",
                    }
                )
    return rows


def build_summary_rows(boundary_rows: list[dict]) -> list[dict]:
    groups: dict[tuple[str, str], list[dict]] = {}
    for row in boundary_rows:
        key = (row["gamma"], str(row["activation_cost_K"]))
        groups.setdefault(key, []).append(row)

    summary_rows = []
    for (gamma, k), rows in sorted(groups.items(), key=lambda x: (safe_float(x[0][0]), safe_float(x[0][1]))):
        valid_beyond = sum(1 for r in rows if r["boundary_status"] == "3arm_valid_beyond_tested_lambda_range")
        no_region = sum(1 for r in rows if r["boundary_status"] == "no_3arm_region_in_tested_lambda_range")
        found = sum(1 for r in rows if r["boundary_status"] == "switching_boundary_found")
        avg_positive_grids = sum(safe_float(r["positive_lambda_grid_count"]) for r in rows) / len(rows)
        summary_rows.append(
            {
                "gamma": gamma,
                "activation_cost_K": k,
                "case_count": len(rows),
                "boundary_found_count": found,
                "always_3arm_in_tested_range_count": valid_beyond,
                "no_3arm_region_count": no_region,
                "average_positive_lambda_grid_count": round2(avg_positive_grids),
                "note": "critical lambda decreases when risk aversion or activation cost increases",
            }
        )
    return summary_rows


def boundary_sort_value(row: dict) -> float:
    text = str(row.get("critical_lambda_star", ""))
    if text.startswith(">"):
        return safe_float(text[1:]) + 1000
    return safe_float(text)


def build_key_case_rows(boundary_rows: list[dict]) -> list[dict]:
    selected_scenarios = [
        (0, 0, "ideal_low_penalty"),
        (0.5, 4, "efficiency_oriented"),
        (1, 8, "balanced_operation"),
        (1.5, 10, "conservative_operation"),
        (2, 12, "strict_conservative"),
    ]
    result = []
    for gamma, k, name in selected_scenarios:
        rows = [
            r
            for r in boundary_rows
            if abs(safe_float(r["gamma"]) - gamma) < 1e-9
            and abs(safe_float(r["activation_cost_K"]) - k) < 1e-9
        ]
        rows = sorted(rows, key=boundary_sort_value, reverse=True)
        for rank, row in enumerate(rows, start=1):
            out = {
                "policy_name": name,
                "rank_by_boundary": rank,
            }
            out.update(row)
            result.append(out)
    return result


def build_parameter_rows() -> list[dict]:
    return [
        {
            "parameter": "model_objective",
            "value": "solve critical lambda where F(lambda,gamma,K)=0",
            "meaning": "find the switching boundary between two-arm and three-arm modes",
        },
        {
            "parameter": "base_data",
            "value": "existing Cmax and Energy results from previous scheduling model",
            "meaning": "no new time model or energy model is introduced",
        },
        {
            "parameter": "lambda_values",
            "value": ",".join(display_number(x) for x in LAMBDA_VALUES),
            "meaning": "tested energy penalty weights",
        },
        {
            "parameter": "gamma_values",
            "value": ",".join(display_number(x) for x in GAMMA_VALUES),
            "meaning": "risk-aversion coefficients",
        },
        {
            "parameter": "activation_cost_K",
            "value": ",".join(str(x) for x in ACTIVATION_COST_LEVELS),
            "meaning": "fixed activation cost levels of enabling the third arm",
        },
        {
            "parameter": "nonlinear_structure_penalty",
            "value": "Phi(p,r)=1+0.20*r^2+0.25*I(p)+0.15*p4^2",
            "meaning": "task structure and scale related nonlinear coordination penalty",
        },
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description="Nonlinear switching boundary optimization.")
    parser.add_argument("--summary-input", default=str(DEFAULT_SUMMARY_INPUT))
    parser.add_argument("--robust-input", default=str(DEFAULT_ROBUST_INPUT))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    args = parser.parse_args()

    summary_path = Path(args.summary_input)
    robust_path = Path(args.robust_input)
    output_dir = Path(args.output_dir)

    structure_rows = load_structure_rows(summary_path)
    robust_map = load_robust_map(robust_path)

    parameter_rows = build_parameter_rows()
    boundary_rows = build_boundary_rows(structure_rows, robust_map)
    summary_rows = build_summary_rows(boundary_rows)
    key_case_rows = build_key_case_rows(boundary_rows)

    save_csv(parameter_rows, output_dir / "switching_boundary_parameters.csv")
    save_csv(boundary_rows, output_dir / "switching_boundary_result.csv")
    save_csv(summary_rows, output_dir / "switching_boundary_summary.csv")
    save_csv(key_case_rows, output_dir / "switching_boundary_key_cases.csv")

    print("Nonlinear switching boundary optimization finished.")
    print(f"Summary input: {summary_path}")
    print(f"Robust input: {robust_path}")
    print(f"Output directory: {output_dir}")
    print(f"Structure rows: {len(structure_rows)}")
    print(f"Robust score entries: {len(robust_map)}")
    print(f"Boundary rows: {len(boundary_rows)}")
    print("Generated:")
    print("  switching_boundary_parameters.csv")
    print("  switching_boundary_result.csv")
    print("  switching_boundary_summary.csv")
    print("  switching_boundary_key_cases.csv")
    print("Model: F(lambda,gamma,K)=mean(S_lambda)-gamma*std(S_lambda)-K*Phi(p,r)")
    print("No new time or energy model is introduced.")


if __name__ == "__main__":
    main()
