# -*- coding: utf-8 -*-
"""Run all nonlinear-analysis scripts in the recommended order."""
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = [
    "analyze_basic_mode_decision_summary.py",
    "nonlinear_task_structure_optimization.py",
    "nonlinear_third_arm_activation_cost.py",
    "nonlinear_robust_mode_selection.py",
    "nonlinear_switching_boundary_optimization.py",
    "nonlinear_integrated_policy_decision.py",
    "nonlinear_make_figures.py",
    "nonlinear_advanced_extensions.py",
]

for name in SCRIPTS:
    path = ROOT / "scripts" / name
    print(f"\n>>> running {path}", flush=True)
    subprocess.run([sys.executable, str(path)], cwd=str(ROOT), check=True)

print("\nAll nonlinear analyses completed.")
